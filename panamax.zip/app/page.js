"use client";
import Home from "@/components/Home";

export default function HomePage() {
  return <Home />;
}
